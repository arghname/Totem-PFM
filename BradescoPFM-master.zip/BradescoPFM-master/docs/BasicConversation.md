Exemplos - Reativo:
Cliente: “BIA, posso jantar no Fasano com minha esposa hoje?”
BIA: “Em média, um casal gasta R$ 300,00 num jantar no Fasano. Considerando seus gastos até o dia de hoje, você não compromete seu padrão de gastos.”

Cliente: “BIA, posso jantar no Fasano?”
BIA: “Quando?”
Cliente: “No sábado.”
BIA: “Com quantas pessoas?”
Cliente: “Duas.”
BIA: “Em média, um casal gasta R$ 300,00 num jantar no Fasano. Considerando seus gastos até o dia de hoje, você não compromete seu padrão de gastos.”

Cliente: “BIA, quando vai dar para eu comprar um smartphone novo?”
BIA: “Se você mantiver seu padrão de gastos, você pode comprar um iPhone 10 de R$10.000,00 em 2 anos.” 

------

Exemplos - Proativo:
<Cliente dispara trigger de reporting por narração>
BIA: “Olá, César! Olhando semana passada, seu saldo foi positivo porque conseguiu economizar 300 reais. Olhando pra semana que vem, você normalmente paga 540 reais em contas, então pode ser que fique negativo.”

