﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PFM.Bot.Utils
{
    public class Settings
    {
        public static string AccountId = "1009081-0";
    }
}