﻿namespace PFM.Products.Interfaces
{
    public interface IProduct
    {
        string Id { get; }
        decimal Price { get; }
    }
}