﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PFM.Core.Models.Balance
{
    public class SummaryEntry
    {
        public string Name { get; set; }
        public decimal Value { get; set; }
        public string Category { get; set; }
    }
}
