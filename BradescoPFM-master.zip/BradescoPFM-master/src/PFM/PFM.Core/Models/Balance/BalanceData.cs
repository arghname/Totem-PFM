﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PFM.Core.Models.Balance
{
    public class BalanceData
    {
        public string AccountId { get; set; }
        public decimal Value { get; set; }
    }
}
