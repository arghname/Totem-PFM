﻿namespace PFM.Core.Interfaces.Products
{
    public interface IProduct
    {
        string Id { get; }
        decimal Price { get; }
    }
}