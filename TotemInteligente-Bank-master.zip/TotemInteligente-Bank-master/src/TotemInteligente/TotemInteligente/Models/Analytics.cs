﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TotemInteligente.Models;

namespace TotemInteligente.Models
{
    public class Analytics
    {
        public UserData UserInfos { get; set; }
        public Messages Message { get; set; }
    }
}
